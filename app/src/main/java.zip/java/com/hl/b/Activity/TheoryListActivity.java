package com.hl.b.Activity;

import android.os.Bundle;
import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.hl.b.ListFragment.TheoryListFragment;
import com.hl.b.R;

/**
 * Created by huanglei on 2018/1/19.
 */

public class TheoryListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.ac_theory_list);

        FragmentManager fragmentManager = getFragmentManager ();         //获取FragmentManger对象
        Fragment fragment = fragmentManager.findFragmentById (R.id.theory_content);

        if (fragment == null) {
            fragment = new TheoryListFragment (fragmentManager);
            fragmentManager.beginTransaction ()
                    .add (R.id.theory_content, fragment)
                    .commit ();
        }
    }
}
