package com.hl.b.TabFragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.hl.b.Activity.RepairListActivity;
import com.hl.b.R;

/**
 * Created by Jay on 2015/8/28 0028.
 */
public class RepairTabFragment extends Fragment {

    private Button listButton;

    public RepairTabFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_repair,container,false);
        listButton = (Button) view.findViewById(R.id.list_repair);
         return view;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        listButton.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                /*FragmentTransaction ft = getFragmentManager().beginTransaction();
                TheoryListFragment nlFragment = new TheoryListFragment (getFragmentManager ());
                ft.replace(R.id.ly_content, nlFragment);
                ft.addToBackStack (null);
                ft.commit();
                Toast.makeText (getActivity (),"List",Toast.LENGTH_LONG).show ();
                Log.d ("MMM","MMM");*/

                Intent intent = new Intent (getActivity (), RepairListActivity.class);
                startActivity (intent);
            }
        });
    }
}
