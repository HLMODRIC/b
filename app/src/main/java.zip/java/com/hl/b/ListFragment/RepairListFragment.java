package com.hl.b.ListFragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hl.b.Activity.TheoryContentActivity;
import com.hl.b.R;
import com.hl.b.db.Data;
import com.hl.b.db.MyDBOpenHelper;

import java.util.ArrayList;

/**
 * Created by Jay on 2015/9/6 0006.
 */
@SuppressLint("ValidFragment")
public class RepairListFragment extends Fragment {
    private FragmentManager fManager;
    private ArrayList<Data> datas;
    private SQLiteDatabase dbRead;
    //1.18
    private RecyclerView mCrimeRecyclerView;
    private DataAdapter mAdapter;
    //1.18
    MyDBOpenHelper dbHelper;
    String titleStr;
    String contentStr;
    int mid;
    private Cursor mCursor;

    public RepairListFragment(FragmentManager fManager) {
        this.fManager = fManager;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate (R.layout.recycler_list, container, false);
        //1.18
        mCrimeRecyclerView = ( RecyclerView ) view
                .findViewById (R.id.recycler_view);
        mCrimeRecyclerView.setLayoutManager (new LinearLayoutManager (getActivity ()));
        //1.18


        //db数据库
        dbHelper = new MyDBOpenHelper (view.getContext ());  //注意：dbHelper的实体化

        //查询数据库
        dbRead = dbHelper.getReadableDatabase ();
        mCursor = dbRead.query ("android", null, null, null, null, null, null);  //查询所有数据
        int num = mCursor.getColumnCount ();
        Log.d ("Th", String.valueOf (num));
        datas = new ArrayList<Data> ();
        while (mCursor.moveToNext ()) {
            //for (int i = 0; i < num; i++) {
                mid = mCursor.getInt (mCursor.getColumnIndex ("id"));
                titleStr = mCursor.getString (mCursor.getColumnIndex ("title"));
                contentStr = mCursor.getString (mCursor.getColumnIndex ("content"));
                Data data = new Data (mid, titleStr, contentStr);
                datas.add (data);
                //Toast.makeText (getActivity (), mid + titleStr + contentStr, Toast.LENGTH_SHORT).show ();
            //}
        }
        dbHelper.close ();

        updateUI();

        return view;
    }
    private void updateUI() {
        mAdapter = new DataAdapter (datas);
        mCrimeRecyclerView.setAdapter(mAdapter);
    }


    /*@Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        FragmentTransaction fTransaction = fManager.beginTransaction ();
        TheoryContentFragment ncFragment = new TheoryContentFragment ();
        Bundle bd = new Bundle ();
        bd.putString ("content", datas.get (position).getNew_content ());
        ncFragment.setArguments (bd);
        //获取Activity的控件
        TextView txt_title = ( TextView ) getActivity ().findViewById (R.id.txt_topbar);
        txt_title.setText (datas.get (position).getNew_title ());
        fTransaction.replace (R.id.ly_content, ncFragment);
        //调用addToBackStack将Fragment添加到栈中
        fTransaction.addToBackStack (null);
        fTransaction.commit ();
    }*/

    private class DataHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private Data mData;
        public TextView mTitleTextView;

        public DataHolder(View view) {
            super (view);
            mTitleTextView = ( TextView ) view.findViewById (R.id.txt_item_title);
            itemView.setOnClickListener (this);
        }
        @Override
        public void onClick(View v) {
            /*FragmentTransaction fTransaction = fManager.beginTransaction ();
            TheoryContentFragment ncFragment = new TheoryContentFragment ();
            Bundle bd = new Bundle ();
            bd.putString ("content", datas.get (getPosition ()).getNew_content ());
            ncFragment.setArguments (bd);
            fTransaction.replace (R.id.theory_content, ncFragment);
            //调用addToBackStack将Fragment添加到栈中
            fTransaction.addToBackStack (null);
            fTransaction.commit ();*/
            //1.19
            Intent intent=new Intent ();
            intent.setClass(getActivity(), TheoryContentActivity.class);
            Bundle bundle=new Bundle();
            bundle.putString("data",datas.get (getPosition ()).getNew_content ());
            intent.putExtras(bundle);
            startActivity(intent);
            // Intent intent = BActivity.newIntent (getActivity (), mData.getId ());
           // startActivity (intent);
        }

    }

    private class DataAdapter extends RecyclerView.Adapter<DataHolder> {
        private ArrayList<Data> datas;
        private int position;

        public DataAdapter(ArrayList<Data> datas) {
            this.datas = datas;
        }

        @Override
        public DataHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from (getActivity ());
            View view = layoutInflater
                    .inflate (R.layout.recycler_list_item, parent, false);
            return new DataHolder (view);
        }

        @Override
        public void onBindViewHolder(DataHolder holder, final int position) {
            Data data = datas.get (position);
            holder.mTitleTextView.setText (data.getNew_title ());
        }

        @Override
        public int getItemCount() {
            return datas.size ();
        }
    }
}


