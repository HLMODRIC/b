package com.hl.b.TabFragment;


import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.hl.b.Activity.TheoryListActivity;
import com.hl.b.R;

/**
 * Created by Jay on 2015/8/28 0028.
 */
public class TheoryTabFragment extends Fragment {

    private FragmentManager fManager;
    private Button listButton;

    public TheoryTabFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_theory,container,false);
        listButton = (Button) view.findViewById(R.id.list_theory);
        /*TheoryListFragment nlFragment = new TheoryListFragment (fManager);
        FragmentTransaction ft = fManager.beginTransaction();
        ft.replace(R.id.ly_content, nlFragment);
        ft.addToBackStack (null);
        ft.commit();*/
         return view;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        listButton.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                /*FragmentTransaction ft = getFragmentManager().beginTransaction();
                TheoryListFragment nlFragment = new TheoryListFragment (getFragmentManager ());
                ft.replace(R.id.ly_content, nlFragment);
                ft.addToBackStack (null);
                ft.commit();
                Toast.makeText (getActivity (),"List",Toast.LENGTH_LONG).show ();
                Log.d ("MMM","MMM");*/

                Intent intent = new Intent (getActivity (), TheoryListActivity.class);
                startActivity (intent);
            }
        });
    }
}
